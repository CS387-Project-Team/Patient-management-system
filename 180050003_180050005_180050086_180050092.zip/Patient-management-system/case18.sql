--Register as a person in the hospital

insert into person
values (10,'Ramu','IITB',400321,'123454657890','M','ramu40','postgres','ramu@gmail.com','2000-01-01',NULL)