
-- Use case: Add test results

-- $6 is bill no, so optiional at this time
insert into takes values ($1, $2, $3, $4, $5,$6);